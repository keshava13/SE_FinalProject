from django.apps import AppConfig


class RaildataConfig(AppConfig):
    name = 'raildata'
