from django.apps import AppConfig


class BookticketConfig(AppConfig):
    name = 'bookticket'
