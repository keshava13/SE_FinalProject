import loginmodule
from raildata.models import Reservation, Tickets, Train, UserDetails
from django.contrib.auth.base_user import AbstractBaseUser
from django.shortcuts import redirect, render
from django.http import HttpResponseRedirect
from django.contrib import auth
from django.template.context_processors import csrf
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
import random


@login_required(login_url='loginmodule:login')
def cancle(request):
    if request.method=="POST":
        if 'cancel' in request.POST:
            ticket = request.POST.get("ticket")
            t=Tickets.objects.get(Ticketno=ticket)
            t.delete()
            return HttpResponseRedirect("/loginmodule/home/")
        else:
            ticket = request.POST.get("ticket")
            t=Tickets.objects.get(Ticketno=ticket)
            return render(request,'cancle.html',{'t':t})
    else:
        return render(request,'cancle.html')

@login_required(login_url='loginmodule:login')
def payment(request):
     print(request)
     source=request.session['source']
     #destination=request.POST.get('destination')
     destination=request.session['destination']
     #trainno=request.GET.get('trainno')
     #arrival=request.GET.get('arrival')
     #departure=request.GET.get('departure')
     trainno=request.session['trainno']
     arrival=request.session['arrival']
     departure=request.session['departure']
     if request.method=="POST":
        return HttpResponseRedirect(f"/bookticket/ticket/?source={source}&destination={destination}&trainno={trainno}&arrival={arrival}&departure={departure}")
     else:
        return render(request,'payment.html')

@login_required(login_url='loginmodule:login')
def registration(request): 
    if request.method=="POST":
          gender=request.POST.get('gender')
          seats=request.POST.get('seats')
          age=request.POST.get('age')
          source=request.session['source']
          #destination=request.POST.get('destination')
          destination=request.session['destination']
          trainno=request.session['trainno']
          #trainno = request.POST.get('trainno')
          arrival=request.session['arrival']
          #arrival = request.POST.get('arrival')
          departure=request.session['departure']
          #departure = request.POST.get('trainno')
          print(f"source in reg if block {source}")
          x=Reservation(Age=age,noOfPassenger=seats,Gender=gender)
          x.save()
          
          return HttpResponseRedirect(f"/bookticket/payment/?source={source}&destination={destination}&trainno={trainno}&arrival={arrival}&departure={departure}")
    else:
        return render(request,'registration.html')

@login_required(login_url='loginmodule:login')
def search(request):
    if request.method == "POST":
        if request.POST.get("book"):
            arrival = request.POST.get('arrival')
            #arrival = request.session['arrival']
            #print(arrival)
            departure = request.POST.get('departure')
            #departure = request.session['departure']
            trainno = request.POST.get('trainno')
            #trainno = request.session['trainno']
            #source=request.POST.get('source')
            source=request.session['source']
            #destination=request.POST.get('destination')
            destination=request.session['destination']
            request.session['arrival']=arrival
            request.session['trainno']=trainno
            request.session['departure']=departure
            
            print(f"source in search if block {source}")
            print(f"source in search if block {trainno}")
            #return HttpResponseRedirect("/bookticket/registration/")
            return HttpResponseRedirect(f"/bookticket/registration/?source={source}&destination={destination}&trainno={trainno}&arrival={arrival}&departure={departure}")

        else:
            source = request.POST.get("source")
            destination=request.POST.get("dest")
            arrival = request.POST.get("arrival")
            print(arrival)
            trainno = request.POST.get("trainno")
            departure = request.POST.get("departure")
            #print(source + "in search method else")
            print(f"source in search else block {source}")
            request.session['source'] = source
            request.session['destination']=destination
            request.session['arrival']=arrival
            request.session['trainno']=trainno
            request.session['departure']=departure
            print(request.session['source'])
            print(request.session['destination'])
            print(request.session['arrival'])
            print(request.session['trainno'])
            print(request.session['departure'])
            request.session.save()
            trains=Train.objects.filter(Source__icontains=source,Destination__icontains=destination)
            print(trains)
            return render(request,'search.html',{'trains':trains})

@login_required(login_url='loginmodule:login')
def source_dest(request):
    if request.method=="POST":
        source = request.POST.get("source")
        
        destination=request.POST.get("dest")
        print(f"source in source dest if block {source}")
        request.session['source'] = source
        #print(request.session['source'] + "in source dest method")
        request.session['destination']=destination
        trains=Train.objects.filter(Source__icontains=source,Destination__icontains=destination)
        print(trains)
        # request.session['trainno']=trains.Trainno
        # request.session['arrival']=trains.arrivaltime
        # request.session['departure']=trains.departuretime
        
        print(trains)
        return render(request,'search.html',{'trains':trains})
        # return HttpResponseRedirect()
    else:
        return render(request,'source_dest.html')


def timetable(request):
    t=Train.objects.all()
    print(t)
    return render(request,'timetable.html',{'t':t})


def ticket(request):
    c=request.user
    print(c)
    print(c.first_name)
    print(c.last_name)
    
    #source=request.session['source']
    #destination= request.session['destination']
    #trainno=request.session['trainno']
    #arrival=request.session['arrival']
    #departure=request.session['departure']
    source=request.GET.get('source')
    destination= request.GET.get('destination')
    trainno=request.GET.get('trainno')
    arrival=request.GET.get('arrival')
    departure=request.GET.get('departure')
    print(arrival+trainno+departure)
    
    t=Tickets(Source=source,Destination=destination,Trainno=trainno,arrivaltime=arrival,departuretime=departure)
    
    t.save()
    return render(request,'ticket.html',{'t':t}) 

